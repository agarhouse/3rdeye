document.addEventListener('DOMContentLoaded', function() {
    const videoContainer = document.getElementById('videoContainer');
    const loading = document.getElementById('loading');
    
    // Execute script in the active tab to find video elements
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
      chrome.scripting.executeScript({
        target: {tabId: tabs[0].id},
        function: findVideoElements
      }, (results) => {
        loading.style.display = 'none';
        
        if (results && results[0].result.length > 0) {
          const videoSources = results[0].result;
          videoSources.forEach((src, index) => {
            const videoDiv = document.createElement('div');
            
            const linkPara = document.createElement('div');
            linkPara.className = 'video-link';
            linkPara.textContent = src;
            
            const copyButton = document.createElement('button');
            copyButton.className = 'copy-btn';
            copyButton.textContent = 'Copy Link';
            copyButton.addEventListener('click', function() {
              navigator.clipboard.writeText(src)
                .then(() => {
                  copyButton.textContent = 'Copied!';
                  setTimeout(() => {
                    copyButton.textContent = 'Copy Link';
                  }, 2000);
                });
            });
            
            videoDiv.appendChild(linkPara);
            videoDiv.appendChild(copyButton);
            videoContainer.appendChild(videoDiv);
            
            // Add a separator if there are multiple videos
            if (index < videoSources.length - 1) {
              const hr = document.createElement('hr');
              videoContainer.appendChild(hr);
            }
          });
        } else {
          const noVideos = document.createElement('p');
          noVideos.className = 'no-videos';
          noVideos.textContent = 'No video elements found on this page.';
          videoContainer.appendChild(noVideos);
        }
      });
    });
    
    // Function to find video elements in the page
    function findVideoElements() {
      const videoElements = document.querySelectorAll('video');
      const videoSources = [];
      
      videoElements.forEach(video => {
        // Check for specific video ID from the requirement
        if (video.id === 'temVideoElementId' && video.classList.contains('temMainBackground')) {
          videoSources.push(video.src);
        }
        // Also collect other video sources as fallback
        else if (video.src) {
          videoSources.push(video.src);
        }
      });
      
      return videoSources;
    }
  });